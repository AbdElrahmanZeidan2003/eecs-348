#!/bin/bash

echo "Hello, what is your name: "
read name_answer
echo "Nice to meet you, $name_answer"


echo "Copying all .c and .h files to a backup folder..."
mkdir -p backup
cp *.c *.h backup/

echo "done"